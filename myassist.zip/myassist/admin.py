from django.contrib import admin
from .models import *
import json
# Register your models here.
@admin.register(PatientRecord)
class UserAdmin(admin.ModelAdmin):
    list_display = ['name','visit_date','text','keywords']
    def show_keywords(self, obj):
        return ", ".join(json.loads(obj.keywords))
    show_keywords.short_description = 'Keywords'