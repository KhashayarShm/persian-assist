from transformers import AutoTokenizer, AutoModelForTokenClassification
from transformers import pipeline
tokenizer = AutoTokenizer.from_pretrained("HooshvareLab/bert-fa-base-uncased-ner-peyma",trust_remote_code=True)
model = AutoModelForTokenClassification.from_pretrained("HooshvareLab/bert-fa-base-uncased-ner-peyma",trust_remote_code=True)

nlp=pipeline("ner",model=model,tokenizer=tokenizer)

def extract_keywords(text):
    entities = nlp(text)
    keywords = [ent['word'] for ent in entities if ent['entity'].startswith('B-')]
    return list(set(keywords))


