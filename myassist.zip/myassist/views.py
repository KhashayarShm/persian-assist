from django.shortcuts import render,HttpResponse
from .models import PatientRecord
from .nlp_parsbert import extract_keywords
from .speech_to_text import transcribe_audio
import json
import os
from django.conf import settings
from django.utils import timezone
from .audio_utils import convert_to_wav
# Create your views here.

def process_audio(request):
    if request.method == "POST":
        audio_file = request.FILES["audio"]
        if not audio_file:
            return HttpResponse("No file found")
        name=request.POST.get("name","unknown")
        filename=f"{name}_{timezone.now().strftime('%Y%m%d%H%M%S')}.wabm"
        filepath=os.path.join(settings.MEDIA_ROOT,'audio' ,filename)
        os.makedirs(os.path.dirname(filepath),exist_ok=True)
        with open(filepath,'wb+') as f:
            for chunk in audio_file.chunks():
                f.write(chunk)
        try:
            converted_path = convert_to_wav(filepath)
        except Exception as e:
            return HttpResponse(f"Error converting to wabm{str(e)}")
        try:
            text = transcribe_audio(converted_path)
        except Exception as e:
            return HttpResponse(f"Error transcribing audio{str(e)}")
        keywords = extract_keywords(text)

        PatientRecord.objects.create(
            name=name,
            text=text,
            keywords=keywords
        )
        return render(request,'success.html',{'name':name,'text':text,'keywords':keywords,})
    return render(request,'upload.html')

def show_patient(request,pk):
    record=PatientRecord.objects.get(pk=pk)
    keywords=json.loads(record.keywords)
    return render(request,'patient_detail.html',{
        'record':record,
        'keywords':keywords
    })