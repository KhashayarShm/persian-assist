import os
files=[
    'models.py','admin.py','nlp_parsbert.py','views.py','templates/upload.html'
]

with open("all_of_code.txt","w",encoding="utf-8") as out:
    for filename in files:
        out.write(f"=={filename}==\n")
        with(open(filename,"r",encoding="utf-8")) as f:
            out.write(f.read())
