from pydub import AudioSegment
import os
AudioSegment.converter=r"C:\Users\Khashayar\Downloads\ffmpeg-8.0-essentials_build\ffmpeg-8.0-essentials_build\bin\ffmpeg.exe"
AudioSegment.ffprobe = r"C:\Users\Khashayar\Downloads\ffmpeg-8.0-essentials_build\ffmpeg-8.0-essentials_build\bin\ffprobe.exe"
def convert_to_wav(input_path):
    output_path = input_path.rsplit('.', 1)[0] + '.wav'
    audio = AudioSegment.from_file(input_path)
    audio.export(output_path, format='wav')
    return output_path