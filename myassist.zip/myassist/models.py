from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class PatientRecord(models.Model):
    name = models.ForeignKey(User,on_delete=models.CASCADE,related_name='user',max_length=200,verbose_name='نام')
    visit_date = models.DateField(auto_now_add=True,verbose_name='تاریخ ویزیت')
    keywords=models.TextField(verbose_name='کلمات کلیدی')
    text= models.TextField()
    class Meta:
        ordering = ['visit_date']
        indexes=[models.Index(fields=['visit_date','name'])]
        verbose_name='اطلاعات بیمار'
        verbose_name_plural='اطلاعات بیماران'

    def __str__(self):
        return f"{self.name}____{self.visit_date}"