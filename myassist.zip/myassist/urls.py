from . import views
from django.urls import path

app_name = 'myassist'
urlpatterns = [
    path('', views.process_audio, name='index'),
    path('record/', views.show_patient, name='record'),
]